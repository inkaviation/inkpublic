1. Put zip file in directory 'C:\\ink'
2. Unzip as 'C:\\ink\inkcute Firefox'
3. Create a shortcut from the 'C:\ink\inkcute Firefox\launch_ink_firefox.cmd' file on desktop and rename as 'UAT'
4. Execute 'UAT' from desktop